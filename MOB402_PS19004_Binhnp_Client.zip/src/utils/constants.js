export default constant = {
    HOSTING: 'https://bumbled-mob402.herokuapp.com/',
    API_LOGIN: '/api/login',
    API_REGISTER: '/api/register',
    API_PRODUCTS: '/api/products',
    TOKEN_KEY: 'bum'
}